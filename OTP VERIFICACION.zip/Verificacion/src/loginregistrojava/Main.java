package loginregistrojava;

import Forms.LoginFrm;

public class Main {
    
    public static void main(String[] args) {
    LoginFrm mLogin = new LoginFrm();
       mLogin.setVisible(true);      
    }
    
}
