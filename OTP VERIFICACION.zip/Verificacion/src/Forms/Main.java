package Forms;

import pantallpersonalizada.*;

public class Main {

    public static void main(String[] args) {
        Principal mPrincipal = new Principal();
        mPrincipal.setVisible(true);
    }
    
}
